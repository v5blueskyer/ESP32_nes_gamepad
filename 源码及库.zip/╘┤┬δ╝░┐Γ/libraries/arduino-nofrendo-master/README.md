# arduino-nofrendo

This is a special nofrendo version as a Arduino library.

## Implementation

Simple implement all function definded in osd.h to make it work.

Any Arduino platform that have enough processing power should work.

## Examples

- esp32-nofrendo.ino in examples folder is rewritten from https://github.com/espressif/esp32-nesemu.git
